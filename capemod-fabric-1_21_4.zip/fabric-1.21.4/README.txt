Build: push this folder to a GitHub repo -> Actions tab -> build -> download the jar artifact. Or locally: JDK 21 + 'gradle build'. Key J opens the cape menu. Needs Fabric API.
