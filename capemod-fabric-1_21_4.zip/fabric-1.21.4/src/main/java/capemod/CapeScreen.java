package capemod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CapeScreen extends Screen {
    public CapeScreen() { super(Text.literal("Capes")); }

    @Override
    protected void init() {
        int cols = 4, w = 100, h = 20, gap = 4;
        int rows = (CapeManager.CAPES.length + cols - 1) / cols;
        int startX = width / 2 - (cols * w + (cols - 1) * gap) / 2;
        int startY = Math.max(24, height / 2 - (rows * (h + gap)) / 2);
        for (int i = 0; i < CapeManager.CAPES.length; i++) {
            String id = CapeManager.CAPES[i][0], label = CapeManager.CAPES[i][1];
            int x = startX + (i % cols) * (w + gap), y = startY + (i / cols) * (h + gap);
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                CapeManager.select(id);
                close();
            }).dimensions(x, y, w, h).build());
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Choose your cape"), width / 2, 10, 0xFFFFFFFF);
    }
}
