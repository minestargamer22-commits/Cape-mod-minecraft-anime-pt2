package capemod;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;
import java.nio.file.*;

public class CapeManager {
    public static final String[][] CAPES = {
        {"anime","Anime"},
        {"bbo","BBO"},
        {"bmw","BMW"},
        {"cape3","Cape 3"},
        {"demon_slayer","Demon slayer"},
        {"gojo","Gojo"},
        {"gorba_2","Gorba 2"},
        {"loplop","LopLop"},
        {"naruto","Naruto"},
        {"nice","Nice"},
        {"otr","Otr"},
        {"q0ps","Q0ps"},
        {"r_i_p","R I P"},
        {"technoblade","Technoblade"},
        {"teryak","Teryak"},
        {"xxxtentacion_billie_eilish","XXXTentacion x Billie"},
        {"xxxtentacion","XXXTentacion"},
        {"backroom","backroom"},
        {"invitation","invitation"},
        {"xd_khostip","xD khostip"}
    };
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("capemod.txt");
    public static String selected = CAPES[0][0]; // active automatically on first launch

    public static void load() {
        try { if (Files.exists(FILE)) { String s = Files.readString(FILE).trim(); for (String[] c : CAPES) if (c[0].equals(s)) selected = s; } }
        catch (Exception ignored) {}
    }
    public static void select(String id) {
        selected = id;
        try { Files.writeString(FILE, id); } catch (Exception ignored) {}
    }
    public static Identifier texture() { return Identifier.of("capemod", "textures/cape/" + selected + ".png"); }
}
